# Convert images to SVG format

convertSVG <- function(imgPath, width, height) {
my_image <- magick::image_read(imgPath)
my_svg <- magick::image_convert(my_image, format="svg")
magick::image_write(my_svg, paste0(stringr::str_split(imgPath, pattern = "[.]")[[1]][1], ".svg"))
}

myDir <- "C:/Users/andre/Dropbox/Minnesota/myWebsite/themes/starter-hugo-academic/assets/media/icons/brands/"

convertSVG(paste0(myDir, "minnesota-logo.png"))
convertSVG(paste0(myDir, "augsburg-logo.jpg"))
convertSVG(paste0(myDir, "gvsu-logo.png"))
convertSVG(paste0(myDir, "usda-logo.png"))

