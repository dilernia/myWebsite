---
abstract: We derive an asymptotic joint distribution and novel covariance estimator for the partial correlations of a multivariate Gaussian time series given mild regularity conditions. Using our derived asymptotic distribution, we develop a Wald confidence interval and testing procedure for inference of individual partial correlations for time series data. Through simulation we demonstrate that our proposed confidence interval attains higher coverage rates, and our testing procedure attains false positive rates closer to the nominal levels than approaches that assume independent observations when autocorrelation is present.

authors:
- Andrew S. DiLernia
- Mark Fiecas
- Lin Zhang
date: "2024-02-24T00:00:00Z"
date_end: "2024-02-24T00:00:00Z"
doi: "https://doi.org/10.1093/biomet/asae012"
featured: false
image: 
  caption: ''
  focal_point: 
  preview_only: false
projects: []
publication: '*Biometrika*'
publication_short: "Supplementary material for Inference of partial correlations of a multivariate Gaussian time series is available [here](https://oup.silverchair-cdn.com/oup/backfile/Content_public/Journal/biomet/PAP/10.1093_biomet_asae012/1/asae012_supplementary_data.pdf?Expires=1714317512&Signature=h6VP6J0LHw8gDQAwDyBC6pW3dfaJrscG4S7VhuKlQ2pU4Ikfqkpwz1rFeLw-ZtCqP7~syVgCdfReLaWaMXgmx7~cHi0UklI8LFbsDAlEqJk5L6w2szDa5CXHf6bwmHZudgWuuygnXzWS6jgd~dm1k7kyVNCkJ5b9z3TV1m-RwF1Q0J-4NmTj6f~Z-iHF~28fpZcp6W4qnQBWUQk5E~8HnEAMoTJZaR1LTeeCft292WLuPPtffbmY5mu9W4PwidUd6JJJ2~etqHbwsvyb6j0cBfkG4lVDt3V6~RQqa4oLAszCSfO5ZrulSf43qAbw5qSZCcZxUmdTfFVg3mMiRdBsDQ__&Key-Pair-Id=APKAIE5G5CRDK6RD3PGA)."
publication_types:
- "2"
publishDate: "2024-02-24T00:00:00Z"
summary:

tags:
title: Inference of partial correlations of a multivariate Gaussian time series
url_code: ""
url_dataset: ""
url_pdf: files/pccov.pdf
url_poster: ""
url_project: ""
url_slides: ""
url_source: ""
url_video: ""
links:
  - name: "R package"
    url: "https://github.com/dilernia/pcCov"
  - name: "Supplementary material"
    url: "https://oup.silverchair-cdn.com/oup/backfile/Content_public/Journal/biomet/PAP/10.1093_biomet_asae012/1/asae012_supplementary_data.pdf?Expires=1714317512&Signature=h6VP6J0LHw8gDQAwDyBC6pW3dfaJrscG4S7VhuKlQ2pU4Ikfqkpwz1rFeLw-ZtCqP7~syVgCdfReLaWaMXgmx7~cHi0UklI8LFbsDAlEqJk5L6w2szDa5CXHf6bwmHZudgWuuygnXzWS6jgd~dm1k7kyVNCkJ5b9z3TV1m-RwF1Q0J-4NmTj6f~Z-iHF~28fpZcp6W4qnQBWUQk5E~8HnEAMoTJZaR1LTeeCft292WLuPPtffbmY5mu9W4PwidUd6JJJ2~etqHbwsvyb6j0cBfkG4lVDt3V6~RQqa4oLAszCSfO5ZrulSf43qAbw5qSZCcZxUmdTfFVg3mMiRdBsDQ__&Key-Pair-Id=APKAIE5G5CRDK6RD3PGA"

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
---