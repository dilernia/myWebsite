---
abstract: We consider a novel problem, bi-level graphical modeling, in which multiple individual graphical models can be considered as variants of a common group-level graphical model and inference of both the group- and individual-level graphical models are of interest. Such a problem arises from many applications, including multi-subject neuroimaging and genomics data analysis. We propose a novel and efficient statistical method, the random covariance model, to learn the group- and individual-level graphical models simultaneously. The proposed method can be nicely interpreted as a random covariance model that mimics the random effects model for mean structures in linear regression. It accounts for similarity between individual graphical models, identifies group-level connections that are shared by individuals, and simultaneously infers multiple individual-level networks. Compared to existing multiple graphical modeling methods that only focus on individual-level graphical modeling, our model learns the group-level structure underlying the multiple individual graphical models and enjoys computational efficiency that is particularly attractive for practical use. We further define a measure of degrees-of-freedom for the complexity of the model useful for model selection. We demonstrate the asymptotic properties of our method and show its finite-sample performance through simulation studies. Finally, we apply the method to our motivating clinical data, a multi-subject resting-state functional magnetic resonance imaging (fMRI) dataset collected from participants diagnosed with schizophrenia, identifying both individual- and group-level graphical models of functional connectivity.
author_notes:
- Equal contribution
- Equal contribution
authors:
- Lin Zhang
- Andrew S. DiLernia
- Karina Quevedo
- Jazmin Camchong
- Kelvin Lim
- Wei Pan
date: "2020-08-31T00:00:00Z"
doi: "doi:10.1111/biom.13364"
featured: false
image: 
  caption: ''
  focal_point: ""
  preview_only: false
projects: []
publication: '*Biometrics*'
publication_short: ""
publication_types:
- "2"
publishDate: "2020-08-31T00:00:00Z"
summary:
tags:
title: A random covariance model for bi‐level graphical modeling with application to resting‐state fMRI data
url_code: ""
url_dataset: ""
url_pdf: https://onlinelibrary.wiley.com/doi/epdf/10.1111/biom.13364
url_poster: ""
url_project: ""
url_slides: ""
url_source: ""
url_video: ""
---