---
abstract: Metabolic activation of many carcinogens leads to formation of reactive intermediates that form DNA adducts. These adducts are cytotoxic when they interfere with cell division. They can also cause mutations by miscoding during DNA replication. Therefore, an individual’s risk of developing cancer will depend on the balance between these processes as well as their ability to repair the DNA damage. Our hypothesis is that variations of genes participating in DNA damage repair and response pathways play significant roles in an individual’s risk of developing tobacco-related cancers. To test this hypothesis, 61 human B-lymphocyte cell lines from the International HapMap project were phenotyped for their sensitivity to the cytotoxic and genotoxic properties of a model methylating agent, N-nitroso-N-methylurethane (NMUr). Cell viability was measured using a luciferase-based assay. Repair of the mutagenic and toxic DNA adduct, O<sup>6</sup>-methylguanine (O<sup>6</sup>-mG), was monitored by LC-MS/MS analysis. Genotoxic potential of NMUr was assessed employing a flow-cytometry based in-vitro mutagenesis assay in the phosphatidylinositol-glycan biosynthesis class-A (PIG-A) gene. A wide distribution of responses to NMUr was observed with no correlation to gender or ethnicity. While the rate of O<sup>6</sup>-mG repair partially influenced the toxicity of NMUr, it did not appear to be the major factor affecting individual susceptibility to the mutagenic effects of NMUr. Genome-wide analysis identified several novel single nucleotide polymorphisms to be explored in future functional validation studies for a number of the toxicological endpoints.
authors:
- Lisa A. Peterson
- Igor V. Ignatovich
- Alex E. Grill
- Amanda Beauchamp
- Yen-Yi Ho
- Andrew S. DiLernia
- Lin Zhang
date: "2019-10-07T00:00:00Z"
doi: ""
featured: false
image: 
  caption: ''
  focal_point: 
  preview_only: false
projects: []
publication: '*Chemical Research in Toxicology*'
publication_short: ""
publication_types:
- "2"
publishDate: "2019-10-07T00:00:00Z"
summary:
tags:
title: Individual differences in the response of human β-lymphoblastoid cells to the cytotoxic, mutagenic and DNA damaging effects of a DNA methylating agent, N-methylnitrosourethane
url_code: ""
url_dataset: ""
url_pdf: https://pubs.acs.org/doi/abs/10.1021/acs.chemrestox.9b00266
url_poster: ""
url_project: ""
url_slides: ""
url_source: ""
url_video: ""
# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
---