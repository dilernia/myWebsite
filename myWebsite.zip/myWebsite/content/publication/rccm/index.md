---
abstract: Functional magnetic resonance imaging (fMRI) data have become increasingly available and are useful for describing functional connectivity (FC), the relatedness of neuronal activity in regions of the brain. This FC of the brain provides insight into certain neurodegenerative diseases and psychiatric disorders, and thus is of clinical importance. To help inform physicians regarding patient diagnoses, unsupervised clustering of subjects based on FC is desired, allowing the data to inform us of groupings of patients based on shared features of connectivity. Since heterogeneity in FC is present even between patients within the same group, it is important to allow subject-level differences in connectivity, while still pooling information across patients within each group to describe group-level FC. To this end, we propose a random covariance clustering model (RCCM) to concurrently cluster subjects based on their FC networks, estimate the unique FC networks of each subject, and to infer shared network features. Although current methods exist for estimating FC or clustering subjects using fMRI data, our novel contribution is to cluster or group subjects based on similar FC of the brain while simultaneously providing group- and subject-level FC network estimates. The competitive performance of RCCM relative to other methods is demonstrated through simulations in various settings, achieving both improved clustering of subjects and estimation of FC networks. Utility of the proposed method is demonstrated with application to a resting-state fMRI data set collected on 43 healthy controls and 61 participants diagnosed with schizophrenia.

authors:
- Andrew S. DiLernia
- Karina Quevedo
- Jazmin Camchong
- Kelvin Lim
- Wei Pan
- Lin Zhang
date: "2021-02-02T00:00:00Z"
doi: 
featured: false
image: 
  caption: ''
  focal_point: 
  preview_only: false
projects: []
publication: '*Biostatistics*'
publication_short: ""
publication_types:
- "2"
publishDate: "2021-02-02T00:00:00Z"
summary:
tags:
title: Penalized model-based clustering of fMRI data
url_code: ""
url_dataset: ""
url_pdf: https://academic.oup.com/biostatistics/advance-article/doi/10.1093/biostatistics/kxaa061/6126173?guestAccessKey=bff886fb-d708-41df-aa56-828c024c3e7f
url_poster: ""
url_project: ""
url_slides: ""
url_source: ""
url_video: ""

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
---