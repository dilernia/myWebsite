---
abstract: In all four major North American professional sports (baseball, basketball, football, and hockey), the primary aim of the regular season is to identify the best teams. Yet the number of regular season games used to distinguish between the teams differs dramatically between the sports, ranging from 16 (football) to 82 (basketball and hockey) to 162 (baseball). While length of season is partially determined by factors including travel logistics, rest requirements, playoff structure and television contracts, from a statistical perspective the 10-fold difference in the number of games between leagues suggests that some league’s games are more “informative” than others. In this paper, we propose a method to quantify the amount of information games yield about the relative strengths of the teams involved. Our strategy is to estimate a predictive accuracy curve which assesses how well simple paired comparison models fitted from X% of games within a season predict the outcomes of the remaining (100 - X)% of games, across multiple values of X. We compare predictive accuracy curves between seasons within each sport and across all sports, and find dramatic differences in the amount of information yielded by game results in the four major North American sports leagues.
authors:
- Julian Wolfson
- Joseph S. Koopmeiners
- Andrew S. DiLernia
date: "2018-03-31T00:00:00Z"
doi: ""
featured: false
image: 
  caption: ''
  focal_point: 
  preview_only: false
projects: []
publication: '*Journal of Sports Analytics, 4*(2)'
publication_short: ""
publication_types:
- "2"
publishDate: "2018-03-31T00:00:00Z"
summary:
tags:
title: Who’s good this year? Comparing the information content of games in the four major US sports
url_code: ""
url_dataset: ""
url_pdf: https://content.iospress.com/articles/journal-of-sports-analytics/jsa199
url_poster: ""
url_project: ""
url_slides: ""
url_source: ""
url_video: ""
# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
---