---
# An instance of the Experience widget.
# Documentation: https://wowchemy.com/docs/page-builder/
widget: experience

# This file represents a page section.
headless: true

# Order that this section appears on the page.
weight: 40

title: Experience
subtitle:

# Date format for experience
#   Refer to https://wowchemy.com/docs/customization/#date-format
date_format: Jan 2006

# Experiences.
#   Add/remove as many `experience` items below as you like.
#   Required fields are `title`, `company`, and `date_start`.
#   Leave `date_end` empty if it's your current employer.
#   Begin multi-line descriptions with YAML's `|2-` multi-line prefix.
experience:
  - title: Assistant Professor, Statistics
    company: Grand Valley State University
    company_url: 'https://www.gvsu.edu/'
    company_logo: gvsu-logo
    location: Allendale, MI
    date_start: '2021-08-01'
    date_end: ''
    description:

  - title: Graduate Research and Teaching Assistant
    company: University of Minnesota, Twin Cities
    company_url: 'https://twin-cities.umn.edu/'
    company_logo: minnesota-logo
    location: Minneapolis, MN
    date_start: '2016-08-01'
    date_end: '2021-07-31'
    description: |2-
        <details>
        <summary>...see more</summary>
        <br>
        &emsp; (1) Research assistant: <br>
        <br>
        &emsp; • Developed and implemented novel machine learning methods for the analysis of high-dimensional neuroimaging data. <br> 
        &emsp; • Used remote Linux servers for parallel computing <br> 
        &emsp; • Analyzed time series data for physical activity classification using machine learning <br> 
        &emsp; • Produced analysis reports using RMarkdown for reproducible research. <br> 
        &emsp; • Created R packages for implementing novel statistical methods available via GitHub in R and C++ <br> 
        <br>
        &emsp; (2) Teaching assistant: <br> 
        <br>
        &emsp; • Graded assignments, created assignment solutions, held office hours, and developed materials for the following courses: Advanced Longitudinal Data Analysis, Biostatistics Modeling and Methods, Exploring and Visualizing Data in R, Advanced Programming <br> and Data Analysis in R. <br>
        &emsp; 
        </details>

  - title: Statistics Instructor
    company: Augsburg University
    company_url: 'https://www.augsburg.edu/'
    company_logo: augsburg-logo
    location: Minneapolis, MN
    date_start: '2019-09-01'
    date_end: '2021-05-31'
    description: |2-
        <details>
        <summary>...see more</summary>
        <br>
        Full instructor for the following courses: <br>
        <br>
        &emsp; (1) MAT 213: Data Visualization and Statistical Computing (Spring 2021): <br> <br> 
        &emsp; • Use of R for data wrangling and manipulation, data visualization using ggplot2, R Markdown, importing and combining data sets, web scraping, basics of natural language processing, SQL, interactive visualizations, and dashboards. <br> 
        <br>
        &emsp; (2) MAT 273: Statistical Models (Fall 2019 & 2020): <br> <br> 
        &emsp; • Predictive modeling using R covering linear regression, logistic regression, and time series analysis. <br>
        </details>

  - title: Student Intern Agricultural Statistician
    company: United States Department of Agriculture
    company_url: 'https://www.nass.usda.gov/'
    company_logo: usda-logo
    location: East Lansing, MI
    date_start: '2014-05-01'
    date_end: '2016-07-31'
    description: |2-
        <details>
        <summary>...see more</summary>
        <br>
        • Automated the cleaning and analysis of data for a manure application survey using SAS macros saving hours of weekly work <br>
        • Created report summarizing data from employee satisfaction surveys using SAS macros for reproducibility. <br>
        • Updated the USDA website by performing maintenance of HTML links and uploading weekly crop weather reports to the website. <br>
        • Used SAS, ArcGIS, and other programs to analyze and process data from weekly, monthly, and annual surveys
        </details>

  - title: Statistics Tutor
    company: Grand Valley State University
    company_url: ''
    company_logo: gvsu-logo
    location: Allendale, MI
    date_start: '2013-08-01'
    date_end: '2016-04-30'
    description: |2-
        <details>
        <summary>...see more</summary>
        <br>
        • Assisted students with courses covering SAS programming, SPSS, probability and distribution theory, hypothesis testing, and descriptive statistics
        </details>

design:
  columns: '2'
---
