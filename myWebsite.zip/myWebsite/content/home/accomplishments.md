---
# An instance of the Accomplishments widget.
# Documentation: https://wowchemy.com/docs/page-builder/
widget: accomplishments

# This file represents a page section.
headless: true

# Order that this section appears on the page.
weight: 50

# Note: `&shy;` is used to add a 'soft' hyphen in a long heading.
title: 'Certificates'
subtitle:

# Date format
#   Refer to https://wowchemy.com/docs/customization/#date-format
date_format: Jan 2006

# Accomplishments.
#   Add/remove as many `item` blocks below as you like.
#   `title`, `organization`, and `date_start` are the required parameters.
#   Leave other parameters empty if not required.
#   Begin multi-line descriptions with YAML's `|2-` multi-line prefix.
item:
  - certificate_url: files/Visualization of Biomedical Big Data - Andrew DiLernia Certificate.pdf
    date_end: ''
    date_start: '2017-07-10'
    description: '
    - Data visualization using the ggplot2 package in R, and producing templates for use with multiple data sets 
    
    - Interactive graphics for rapid exploration of Big Data and also how to create simple web GUIs for managing complex summaries of biological data using R Shiny'
    organization: University of Washington, Department of Biostatistics
    organization_url: https://www.biostat.washington.edu
    title: 'Visualization of Biomedical Big Data'
    url: 'https://si.biostat.washington.edu/suminst/sisbid'
    
  - certificate_url: files/Reproducible Research for Biomedical Big Data -Andrew DiLernia Certificate.pdf
    date_end: ''
    date_start: '2017-07-10'
    description: '
    - Use of R and R Markdown for producing reproducible documents
    
    - Techniques for making large-scale data analyses reproducible'
    organization: University of Washington, Department of Biostatistics
    organization_url: https://www.biostat.washington.edu
    title: 'Reproducible Research for Biomedical Big Data'
    url: 'https://si.biostat.washington.edu/suminst/sisbid'

  - certificate_url: files/Data Wrangling with R - Andrew DiLernia Certificate.pdf
    date_end: ''
    date_start: '2017-07-10'
    description: "
    - Creating 'tidy data', data retrieval, manipulation, and formatting
    
    - Reproducible research using R Markdown and collaborative code sharing using GitHub"
    organization: University of Washington, Department of Biostatistics
    organization_url: https://www.biostat.washington.edu
    title: 'Data Wrangling with R'
    url: 'https://si.biostat.washington.edu/suminst/sisbid'

design:
  columns: '2'
---
