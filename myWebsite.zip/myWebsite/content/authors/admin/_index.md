---
authors:
- admin
bio: My research interests pertain to imaging, predictive modeling, and sports for fun.
education:
  courses:
  - course: Ph.D., Biostatistics
    institution: University of Minnesota - Twin Cities
    year: 2021
  - course: B.S., Mathematics and Statistics
    institution: Grand Valley State University
    year: 2016
email: "andrew.s.dilernia@gmail.com"
interests:
- Machine learning methods for neuroimaging data
- Predictive modeling
- Computing and data visualization
- Teaching
name: Andrew DiLernia
organizations:
- name: Grand Valley State University
  url: ""
role: Assistant Professor, Statistics
social:
- icon: google-scholar
  icon_pack: ai
  link: https://scholar.google.com/citations?user=luCTEZYAAAAJ&hl=en
- icon: github
  icon_pack: fab
  link: https://github.com/dilernia
- icon: linkedin
  icon_pack: fab
  link: https://www.linkedin.com/in/andrew-dilernia
superuser: true
user_groups:
- Researchers
- Visitors
---

My name is Andrew DiLernia and I am an assistant professor in the Statistics Department at Grand Valley State University (GVSU). I grew up in Potterville, Michigan and spent my undergraduate years at GVSU. I attended the University of Minnesota - Twin Cities for my graduate studies and thoroughly enjoyed all the wonderful activities that the Twin Cities have to offer. In my free time I enjoy casually playing the piano, running, playing basketball, watching football, and most of all spending time with my cat Lei and significant other Lauren. Fall is by far my favorite season since it has the best weather and scenery of the year.
