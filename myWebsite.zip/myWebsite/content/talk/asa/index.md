---
abstract: Functional magnetic resonance imaging (fMRI) data have become increasingly available and are useful for describing functional connectivity (FC), the relatedness of neuronal activity in regions of the brain. This FC of the brain provides insight into certain neurodegenerative diseases and psychiatric disorders, and thus is of clinical importance. To help inform physicians regarding patient diagnoses, unsupervised clustering of subjects based on FC is desired, allowing the data to inform us of groupings of patients based on shared features of connectivity. Even within these groups of patients, heterogeneity across patients in FC is still present. As such, it is important to allow subject-level differences in connectivity, while still pooling information across patients within each group to describe group-level FC. To this end, we propose a random covariance clustering model (RCCM) to concurrently cluster subjects based on their FC networks, estimate the unique FC networks of each subject, and to infer shared network features. Although current methods exist for estimating FC or clustering subjects using fMRI data, our novel contribution is to cluster or group subjects based on similar FC of the brain while simultaneously providing group- and subject-level FC network estimates. The competitive performance of RCCM relative to other methods is demonstrated through simulations in various settings, achieving both improved clustering of subjects and estimation of FC networks. Utility of the proposed method is demonstrated with application to a resting-state fMRI data set collected on 43 healthy controls and 61 participants diagnosed with schizophrenia.
all_day: false
authors: []
date: "2020-05-21T12:00:00Z"
date_end: "2020-05-21T13:00:00Z"
event: ASA Statistical Methods in Imaging Conference, Student Paper Competition
event_url: https://scholarblogs.emory.edu/smi2020/program/
featured: false
links:
location: Atlanta, Georgia (virtual due to COVID-19)
math: true
summary: ASA Statistical Methods in Imaging Conference Presentation
tags: []
title: Penalized model-based clustering of fMRI data
url_pdf: ""
url_slides: "/files/ASA_Presentation.pdf"
url_video: "https://www.dropbox.com/sh/4bw7dpnhcllh6mq/AAAJ8EXWRp_h4pPEqfIhXAGga/SMI2020_DilerniaWangWu.mp4?dl=0"
url_code: "/files/exampleSimulation.html"
---