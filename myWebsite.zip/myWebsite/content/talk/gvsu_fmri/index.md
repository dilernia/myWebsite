---
abstract: Functional magnetic resonance imaging (fMRI) data is increasingly available and provides insight into the physiological mechanisms of the brain. As psychiatric disorders and many neurodegenerative diseases are intrinsically related to the brain, the availability of fMRI presents valuable opportunities for improving understanding of these disorders and diseases. An overview of fMRI data will be provided, covering the fundamentals of data acquisition, data preprocessing, and common methods of statistical analysis.
all_day: false
authors: []
date: "2023-02-16T12:00:00Z"
date_end: "2023-02-16T13:00:00Z"
event: 
event_url: 
featured: false
links:
location: Allendale, Michigan
math: true
summary: Seminar presented for the Grand Valley State University, Department of Statistics
tags: []
title: Fundamentals of Functional Magnetic Resonance Imaging Data
url_pdf: ""
url_slides: "/files/Fundamentals_of_Functional_Magnetic_Resonance_Imaging_Data.pdf"
url_video: "https://youtu.be/JSSGoVcfXUk"
url_code: 
---